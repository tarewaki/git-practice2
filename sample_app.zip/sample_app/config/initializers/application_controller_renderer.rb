# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '840fc1e97fe458d1ec466d68e4c1ad68df28ee77f8ed83ee5b9a791a71e7430745c222c59f720af4fe6a9824f0f683843d81764d85274e8b6f0f6cd348f90106'
