class Stare < ApplicationRecord
end
