class StareController < ApplicationController
  def middle
  end
end
